package Meneses_ATMMachine;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Withdraw{

	JFrame withdrawframe;
	JLabel bankname, withdrawlabel, entamountlabel;
	JButton acceptbutton, cancelbutton, backbutton;
	JTextField amountfield;
	public static int accid;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Deposit window = new Deposit();
					window.depositframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Withdraw() {
		initialize();
	}
	
	int myaccpin;
	public Withdraw(int accpass) {
		initialize();
		myaccpin = accpass;
		getbalance();
	}
	
	
	

	int oldbalance;
	
	
	private int getbalance() {

		try {
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbatm","root","");
			java.sql.Statement stmt = conn.createStatement();
			String sql = "Select * from tblaccounts where acc_pin ='" +Login.accpin+"'";
			ResultSet rs = stmt.executeQuery(sql);
			
			if(rs.next()) {
			
			oldbalance=rs.getInt("acc_balance");
			
			}
		
		
		} catch(Exception e1) {
			//e1.printStackTrace();
			System.out.print(e1);
		}
		return oldbalance;
	}
	
	int i;
	int balance;
	String accno;
	String name;
	
	private void initialize() {
		withdrawframe = new JFrame();
		withdrawframe.getContentPane().setBackground(new Color(0, 0, 0));
		withdrawframe.getContentPane().setLayout(null);
		withdrawframe.setBounds(100, 100, 500, 350);
		withdrawframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		withdrawframe.setResizable(false);
		withdrawframe.setLocationRelativeTo(withdrawframe);
		
		System.out.println(myaccpin);
		
		bankname = new JLabel("SQL CENTRAL BANK");
		bankname.setFont(new Font("Trebuchet MS", Font.BOLD, 42));
		bankname.setForeground(new Color(255, 255, 255));
		bankname.setBounds(48, 40, 395, 50);
		withdrawframe.getContentPane().add(bankname);
		withdrawframe.getContentPane().setLayout(null);
		
		withdrawlabel = new JLabel("WITHDRAW");
		withdrawlabel.setHorizontalAlignment(SwingConstants.CENTER);
		withdrawlabel.setFont(new Font("Trebuchet MS", Font.BOLD, 25));
		withdrawlabel.setForeground(new Color(255, 255, 255));
		withdrawlabel.setBounds(132, 101, 220, 20);
		withdrawframe.getContentPane().add(withdrawlabel);
		
		backbutton = new JButton("<< BACK");
		backbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Transaction transac = new Transaction();
				transac.transactionframe.setVisible(true);
				withdrawframe.dispose();
			}
		});
		backbutton.setFont(new Font("Trebuchet MS", Font.BOLD, 12));
		backbutton.setBounds(10, 277, 100, 23);
		withdrawframe.getContentPane().add(backbutton);
		
		cancelbutton = new JButton("CANCEL >>");
		cancelbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int result = JOptionPane.showConfirmDialog(withdrawframe,"Do you really want to end this transaction", "Confirmation",
			               JOptionPane.YES_NO_OPTION,
			               JOptionPane.QUESTION_MESSAGE);
			            if(result == JOptionPane.YES_OPTION){
			            	MainForm main = new MainForm();
			            	main.mainframe.setVisible(true);
			            	withdrawframe.dispose();
			               System.out.println("Selected Yes");
			            }else if (result == JOptionPane.NO_OPTION){
			               System.out.println("Selected No");
			            }else {
			               System.out.println("None selected");
			            }
			}
		});
		cancelbutton.setFont(new Font("Trebuchet MS", Font.BOLD, 12));
		cancelbutton.setBounds(374, 278, 100, 23);
		withdrawframe.getContentPane().add(cancelbutton);
		


		acceptbutton = new JButton("ACCEPT");
		acceptbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Accept Button Clicked");
				
				if(amountfield.getText().isEmpty()) {
					JOptionPane.showMessageDialog(withdrawframe, "INPUT VALID AMOUNT", "WARNING", JOptionPane.ERROR_MESSAGE);
					
				} else {
					
					int amount = Integer.parseInt(amountfield.getText());
						
						try {
							String sql = "UPDATE tblaccounts SET acc_balance =? WHERE acc_pin=?";
							Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbatm","root","");							
							java.sql.PreparedStatement pst = conn.prepareStatement(sql);
							pst.setInt(1, getbalance() - Integer.parseInt(amountfield.getText()));
							pst.setString(2, Login.accpin);
							
							if(pst.executeUpdate() == 1) {
								JOptionPane.showMessageDialog(withdrawframe, "ACCOUNT NO: " +Login.accno+"\n"+"ACCOUNT NAME: " +Login.accname+ "\n" + "WITHDRAWAL AMOUNT: "+amount+"\n"+"BALANCE: "+getbalance() );
								System.out.println("Withdraw Successfuly");
								amountfield.setText(null);
								getbalance();
								
								Transaction.main(null);
								withdrawframe.dispose();
							}else if(amount % 100 == 0) {
								JOptionPane.showMessageDialog(withdrawframe, "Please input amount display divisible by 100", "WITHDRAW", JOptionPane.ERROR_MESSAGE);
							}else {
								JOptionPane.showMessageDialog(withdrawframe, "Insuffient Balance.Please check your balance","WITHDRAW",JOptionPane.ERROR_MESSAGE);
							}
						}catch(SQLException ex){
							System.out.println(ex);
						}
					}
				}
		});
		acceptbutton.setFont(new Font("Trebuchet MS", Font.BOLD, 12));
		acceptbutton.setBounds(203, 278, 100, 23);
		withdrawframe.getContentPane().add(acceptbutton);
		
		entamountlabel = new JLabel("Enter Amount");
		entamountlabel.setHorizontalAlignment(SwingConstants.CENTER);
		entamountlabel.setForeground(Color.WHITE);
		entamountlabel.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		entamountlabel.setBounds(132, 151, 220, 20);
		withdrawframe.getContentPane().add(entamountlabel);
		
		amountfield = new JTextField();
		amountfield.setBounds(120, 185, 242, 30);
		withdrawframe.getContentPane().add(amountfield);
		amountfield.setColumns(10);
		
			
	}

}
