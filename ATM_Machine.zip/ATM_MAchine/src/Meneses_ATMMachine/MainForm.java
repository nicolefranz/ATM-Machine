package Meneses_ATMMachine;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainForm {

	JFrame mainframe;
	JLabel bankname;
	JButton startbutton;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainForm window = new MainForm();
					window.mainframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainForm() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		mainframe = new JFrame();
		mainframe.getContentPane().setBackground(new Color(0, 0, 0));
		mainframe.getContentPane().setLayout(null);
		mainframe.setBounds(100, 100, 500, 350);
		mainframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainframe.setLocationRelativeTo(mainframe);
		mainframe.setResizable(false);
		
		bankname = new JLabel("SQL CENTRAL BANK");
		bankname.setFont(new Font("Trebuchet MS", Font.BOLD, 42));
		bankname.setForeground(new Color(255, 255, 255));
		bankname.setBounds(47, 64, 395, 50);
		mainframe.getContentPane().add(bankname);
		
		startbutton = new JButton("START TRANSACTION");
		startbutton.setBackground(new Color(255, 255, 255));
		startbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login log = new Login();
				log.loginframe.setVisible(true);
				mainframe.dispose();
				System.out.println("Transaction Start");
			}
		});
		startbutton.setFont(new Font("Trebuchet MS", Font.BOLD, 15));
		startbutton.setBounds(150, 181, 200, 50);
		mainframe.getContentPane().add(startbutton);
		
		
	}
}
