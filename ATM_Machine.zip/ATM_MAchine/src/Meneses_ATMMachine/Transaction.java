package Meneses_ATMMachine;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Transaction {

	JFrame transactionframe;
	JLabel bankname;
	JButton balancebutton, cancelbutton, depositbutton, withdrawbutton;
	public static int accpin;
	

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Transaction window = new Transaction();
					window.transactionframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Transaction() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		transactionframe = new JFrame();
		transactionframe.getContentPane().setBackground(new Color(0, 0, 0));
		transactionframe.setBounds(100, 100, 500, 350);
		transactionframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		transactionframe.getContentPane().setLayout(null);
		transactionframe.setLocationRelativeTo(transactionframe);
		transactionframe.setResizable(false);
		transactionframe.setVisible(true);
		
		bankname = new JLabel("SQL CENTRAL BANK");
		bankname.setFont(new Font("Trebuchet MS", Font.BOLD, 42));
		bankname.setForeground(new Color(255, 255, 255));
		bankname.setBounds(48, 40, 395, 50);
		transactionframe.getContentPane().add(bankname);
		
		balancebutton = new JButton("BALANCE INQUIRY");
		balancebutton.setBackground(new Color(240, 240, 240));
		balancebutton.setFont(new Font("Trebuchet MS", Font.PLAIN, 18));
		balancebutton.setBounds(48, 137, 180, 40);
		transactionframe.getContentPane().add(balancebutton);
		balancebutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Balance bal = new Balance();
				bal.balanceframe.setVisible(true);
				transactionframe.dispose();
				
				System.out.println("Enter Balance Inquiry");
			}
		});
		
		withdrawbutton = new JButton("WITHDRAW");
		withdrawbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Withdraw with = new Withdraw();
				with.withdrawframe.setVisible(true);
				transactionframe.dispose();
				
				System.out.println("Enter Withdraw");

			}
		});
		withdrawbutton.setFont(new Font("Trebuchet MS", Font.PLAIN, 18));
		withdrawbutton.setBounds(263, 137, 180, 40);
		transactionframe.getContentPane().add(withdrawbutton);
		
		depositbutton = new JButton("DEPOSIT");
		depositbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Deposit depo = new Deposit();
				depo.depositframe.setVisible(true);
				transactionframe.dispose();
				
				System.out.println("Enter Deposit");
			}
		});
		depositbutton.setFont(new Font("Trebuchet MS", Font.PLAIN, 18));
		depositbutton.setBounds(48, 209, 180, 40);
		transactionframe.getContentPane().add(depositbutton);
		
		cancelbutton = new JButton("CANCEL");
		cancelbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int result = JOptionPane.showConfirmDialog(transactionframe,"Do you really want to end this transaction", "Confirmation",
			               JOptionPane.YES_NO_OPTION,
			               JOptionPane.QUESTION_MESSAGE);
			            if(result == JOptionPane.YES_OPTION){
			            	MainForm main = new MainForm();
			            	main.mainframe.setVisible(true);
			            	transactionframe.dispose();
			               System.out.println("Cancel Transaction");
			            }else if (result == JOptionPane.NO_OPTION){
			               System.out.println("Selected No");
			            }else {
			               System.out.println("None selected");
			            }
			}
		});
		cancelbutton.setFont(new Font("Trebuchet MS", Font.PLAIN, 18));
		cancelbutton.setBounds(263, 209, 180, 40);
		transactionframe.getContentPane().add(cancelbutton);
		
		
	}


	
}
