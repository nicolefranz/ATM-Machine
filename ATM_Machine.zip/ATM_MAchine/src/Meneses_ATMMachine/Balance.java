package Meneses_ATMMachine;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class Balance {

	JFrame balanceframe;
	private JLabel bankname, balancelabel, accountno, accountname, accountbalance;
	private JButton backbutton;
	private JButton cancelbutton;
	private JTextField accountfield, namefield, balancefield;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Balance window = new Balance();
					window.balanceframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	
	int myaccpin;
	public Balance(int accpass) {
		initialize();
		myaccpin = accpass;
		getbalance();
	}
	public Balance() {
		initialize();
	}
	
	java.sql.Connection c = null;
	java.sql.PreparedStatement pst = null, pst1 = null;
	java.sql.ResultSet rs = null, rs1=null;
	java.sql.Statement stmt = null, stmt1 = null;
	int oldbalance;
	

	private int getbalance() 
	{

		try {
			Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbatm","root","");
			java.sql.Statement stmt = c.createStatement();
			String sql = "Select * from tblaccounts where acc_pin ='" +Login.accpin+"'";
			 rs1 = stmt.executeQuery(sql);
			
			if(rs1.next()) {
			
			oldbalance=rs1.getInt(5);
			
						}
		
		
		} catch(Exception e1) {
			//e1.printStackTrace();
			System.out.print(e1);
		}
		return oldbalance;
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		balanceframe = new JFrame();
		balanceframe.getContentPane().setBackground(new Color(0, 0, 0));
		balanceframe.getContentPane().setLayout(null);
		balanceframe.setBounds(100, 100, 500, 350);
		balanceframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		balanceframe.setLocationRelativeTo(balanceframe);
		balanceframe.setResizable(false);

		bankname = new JLabel("SQL CENTRAL BANK");
		bankname.setFont(new Font("Trebuchet MS", Font.BOLD, 42));
		bankname.setForeground(new Color(255, 255, 255));
		bankname.setBounds(48, 40, 395, 50);
		balanceframe.getContentPane().add(bankname);
		
		balancelabel = new JLabel("BALANCE INQUIRY");
		balancelabel.setFont(new Font("Trebuchet MS", Font.BOLD, 25));
		balancelabel.setForeground(new Color(255, 255, 255));
		balancelabel.setBounds(140, 101, 220, 20);
		balanceframe.getContentPane().add(balancelabel);
		
		backbutton = new JButton("<< BACK");
		backbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Transaction transac = new Transaction();
				transac.transactionframe.setVisible(true);
				balanceframe.dispose();
			}
		});
		backbutton.setFont(new Font("Trebuchet MS", Font.BOLD, 12));
		backbutton.setBounds(10, 277, 100, 23);
		balanceframe.getContentPane().add(backbutton);
		
		cancelbutton = new JButton("CANCEL >>");
		cancelbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int result = JOptionPane.showConfirmDialog(balanceframe,"Do you really want to end this transaction", "Confirmation",
			               JOptionPane.YES_NO_OPTION,
			               JOptionPane.QUESTION_MESSAGE);
			            if(result == JOptionPane.YES_OPTION){
			            	MainForm main = new MainForm();
			            	main.mainframe.setVisible(true);
			            	balanceframe.dispose();
			               System.out.println("Selected Yes");
			            }else if (result == JOptionPane.NO_OPTION){
			               System.out.println("Selected No");
			            }else {
			               System.out.println("None selected");
			            }
			}
		});
		cancelbutton.setFont(new Font("Trebuchet MS", Font.BOLD, 12));
		cancelbutton.setBounds(374, 277, 100, 23);
		balanceframe.getContentPane().add(cancelbutton);
		
		accountname = new JLabel("Account Name:");
		accountname.setForeground(Color.WHITE);
		accountname.setFont(new Font("Trebuchet MS", Font.BOLD, 15));
		accountname.setBounds(48, 185, 150, 20);
		balanceframe.getContentPane().add(accountname);
		
		accountbalance = new JLabel("Account Balance:");
		accountbalance.setForeground(Color.WHITE);
		accountbalance.setFont(new Font("Trebuchet MS", Font.BOLD, 15));
		accountbalance.setBounds(48, 216, 150, 20);
		balanceframe.getContentPane().add(accountbalance);
		
		accountno = new JLabel("Account Number:");
		accountno.setForeground(Color.WHITE);
		accountno.setFont(new Font("Trebuchet MS", Font.BOLD, 15));
		accountno.setBounds(48, 154, 150, 20);
		balanceframe.getContentPane().add(accountno);
		
		accountfield = new JTextField();
		accountfield.setForeground(new Color(255, 255, 255));
		accountfield.setBackground(new Color(0, 0, 0));
		accountfield.setBounds(181, 154, 262, 20);
		balanceframe.getContentPane().add(accountfield);
		accountfield.setColumns(10);
		
		namefield = new JTextField();
		namefield.setForeground(Color.WHITE);
		namefield.setColumns(10);
		namefield.setBackground(Color.BLACK);
		namefield.setBounds(181, 187, 262, 20);
		balanceframe.getContentPane().add(namefield);
		
		balancefield = new JTextField();
		balancefield.setForeground(Color.WHITE);
		balancefield.setColumns(10);
		balancefield.setBackground(Color.BLACK);
		balancefield.setBounds(181, 216, 262, 20);
		balanceframe.getContentPane().add(balancefield);
		
		try{
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbatm","root","");
            java.sql.Statement stmt = conn.createStatement();
            String sql = "SELECT * FROM tblaccounts WHERE acc_pin=" + Login.accpin + "";

            java.sql.ResultSet rs = stmt.executeQuery(sql);
            if (rs.next()) {
                accountfield.setText(rs.getString("acc_no"));
                namefield.setText(rs.getString("acc_name"));
                balancefield.setText(rs.getString("acc_balance"));
            } else {
                System.out.println("No Record Found");
            }
        }
        catch (SQLException ex){
            System.out.println(ex.getMessage());
        }
	}
}