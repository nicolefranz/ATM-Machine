package Meneses_ATMMachine;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import javax.swing.JPasswordField;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Login {

	JFrame loginframe;
	JLabel bankname, pinnumberlabel;
	JPasswordField password;
	int attempt = 0;
	public static String accpin;
	
	public static String accno;
	public static String accname;
	
	public Login(String accid, String accnames) {
		accno = accid;
		accname = accnames;
	}
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.loginframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		Connection conn = null;
		try {
			conn = (Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/dbatm","root","");
			if(conn!=null) {
				System.out.println("Database is connected");
			}
		}catch(SQLException ex){
			System.out.println("Database is not connected");
		}
	}
	

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		loginframe = new JFrame();
		loginframe.getContentPane().setBackground(new Color(0, 0, 0));
		loginframe.getContentPane().setLayout(null);
		loginframe.setBounds(100, 100, 500, 350);
		loginframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		loginframe.setLocationRelativeTo(loginframe);
		loginframe.setResizable(false);
		
		bankname = new JLabel("SQL CENTRAL BANK");
		bankname.setFont(new Font("Trebuchet MS", Font.BOLD, 42));
		bankname.setForeground(new Color(255, 255, 255));
		bankname.setBounds(47, 64, 395, 50);
		loginframe.getContentPane().add(bankname);
		
		pinnumberlabel = new JLabel("ENTER PIN NUMBER");
		pinnumberlabel.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		pinnumberlabel.setForeground(new Color(255, 255, 255));
		pinnumberlabel.setBounds(142, 144, 220, 20);
		loginframe.getContentPane().add(pinnumberlabel);
		
		password = new JPasswordField();
		password.setBounds(120, 175, 242, 30);
		loginframe.getContentPane().add(password);
		password.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				 if (e.getKeyCode()==KeyEvent.VK_ENTER){
					 String pass = password.getText();
					 try {
						 Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbatm","root","");
						 java.sql.Statement stmt = conn.createStatement();
						 String sql = "Select * from tblaccounts where acc_pin='"+ password.getText()+"'"; 

						 ResultSet rs = ((java.sql.Statement) stmt).executeQuery(sql);
		                 
		                 if (rs.next()) {
		                	 accpin = rs.getString("acc_pin");
		                	 accno = rs.getString("acc_no");
		                	 accname = rs.getString("acc_name");
		                     Transaction trans = new Transaction();
		                     trans.transactionframe.setVisible(true);
		                     loginframe.dispose();
		                     System.out.println(accpin);
		                     
		                     System.out.println("Login Successfully");
		                    } else{
		                    	JOptionPane.showMessageDialog(loginframe, "INCORRECT PIN","PIN ERROR", JOptionPane.WARNING_MESSAGE);
		                        System.out.println("Incorrect Pin");
		                    } 
					 }catch(SQLException ex) {
						 System.out.println(ex);
					 }
					 
					 
					}
				}
		});
		
	}

	
}
