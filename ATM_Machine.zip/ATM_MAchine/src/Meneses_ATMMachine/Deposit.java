package Meneses_ATMMachine;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Deposit {

	JFrame depositframe;
	JLabel bankname, depositlabel, entamountlabel;
	JButton acceptbutton, cancelbutton, backbutton;
	JTextField amountfield;
	public static int accid;
	
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Deposit window = new Deposit();
					window.depositframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Deposit() {
		initialize();
	}
	
	int myaccpin;
	int oldbalance;
	public Deposit(int accpin) {
		initialize();
		myaccpin = accpin;
		getbalance();
		
	}
	
	private int getbalance(){

		try {
			java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbatm","root","");
			java.sql.Statement stmt = conn.createStatement();
			String sql = "Select * from tblaccounts where acc_pin ='" +Login.accpin+"'"; 
			ResultSet rs = stmt.executeQuery(sql);
			rs = stmt.executeQuery(sql);
			
			if(rs.next()) {
			
			oldbalance=rs.getInt("acc_balance");
			
						}
		
		} catch(Exception e1) {
			//e1.printStackTrace();
			System.out.print(e1);
		}
		return oldbalance;
	}

	/**
	 * Initialize the contents of the frame.
	 * @wbp.parser.entryPoint
	 */
	private void initialize() {
		depositframe = new JFrame();
		depositframe.getContentPane().setBackground(new Color(0, 0, 0));
		depositframe.getContentPane().setLayout(null);
		depositframe.setBounds(100, 100, 500, 350);
		depositframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		depositframe.setResizable(false);
		depositframe.setLocationRelativeTo(depositframe);
		
		bankname = new JLabel("SQL CENTRAL BANK");
		bankname.setFont(new Font("Trebuchet MS", Font.BOLD, 42));
		bankname.setForeground(new Color(255, 255, 255));
		bankname.setBounds(48, 40, 395, 50);
		depositframe.getContentPane().add(bankname);
		depositframe.getContentPane().setLayout(null);
		
		depositlabel = new JLabel("DEPOSIT");
		depositlabel.setHorizontalAlignment(SwingConstants.CENTER);
		depositlabel.setFont(new Font("Trebuchet MS", Font.BOLD, 25));
		depositlabel.setForeground(new Color(255, 255, 255));
		depositlabel.setBounds(132, 101, 220, 20);
		depositframe.getContentPane().add(depositlabel);
		
		backbutton = new JButton("<< BACK");
		backbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Transaction transac = new Transaction();
				transac.transactionframe.setVisible(true);
				depositframe.dispose();
			}
		});
		backbutton.setFont(new Font("Trebuchet MS", Font.BOLD, 12));
		backbutton.setBounds(10, 277, 100, 23);
		depositframe.getContentPane().add(backbutton);
		
		cancelbutton = new JButton("CANCEL >>");
		cancelbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int result = JOptionPane.showConfirmDialog(depositframe,"Do you really want to end this transaction", "Confirmation",
			               JOptionPane.YES_NO_OPTION,
			               JOptionPane.QUESTION_MESSAGE);
			            if(result == JOptionPane.YES_OPTION){
			            	MainForm main = new MainForm();
			            	main.mainframe.setVisible(true);
			            	depositframe.dispose();
			               System.out.println("Selected Yes");
			            }else if (result == JOptionPane.NO_OPTION){
			               System.out.println("Selected No");
			            }else {
			               System.out.println("None selected");
			            }
			}
		});
		cancelbutton.setFont(new Font("Trebuchet MS", Font.BOLD, 12));
		cancelbutton.setBounds(374, 278, 100, 23);
		depositframe.getContentPane().add(cancelbutton);
		


		acceptbutton = new JButton("ACCEPT");
		acceptbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(amountfield.getText().isEmpty()) {
					JOptionPane.showMessageDialog(depositframe, "Enter Valid Amount", null, JOptionPane.ERROR_MESSAGE);
				}else {
					int amount = Integer.parseInt(amountfield.getText());
					
					try {
						try {
							
							if(amount >= 100 && amount <= 10000000) {
								String sql = "UPDATE tblaccounts SET acc_balance = ? WHERE acc_pin=?";
								java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbatm","root","");
								java.sql.PreparedStatement pst = conn.prepareStatement(sql);
								pst.setInt(1, getbalance() + Integer.parseInt(amountfield.getText()));
								pst.setString(2, Login.accpin);
								int i = pst.executeUpdate();
								
								if(i>0) {
									sql = "SELECT * FROM tblaccounts WHERE acc_pin = '"+myaccpin+"'";
									ResultSet rs = pst.executeQuery(sql);
									rs.next();
									
									JOptionPane.showMessageDialog(depositframe, "ACCOUNT NO: " +Login.accno+"\n"+"ACCOUNT NAME: " +Login.accname+ "\n" + "WITHDRAWAL AMOUNT: "+amount+"\n"+"BALANCE: "+getbalance() );
									getbalance();
									Transaction.main(null);
									depositframe.dispose();
								}else {
									JOptionPane.showMessageDialog(depositframe, "INvalid Transaction");
								}
							}
						}catch(SQLException ex) {
							System.out.println(ex);
						}
					}catch(Exception ex) {
						System.out.println(ex);
					}
				}
			}
		});
		acceptbutton.setFont(new Font("Trebuchet MS", Font.BOLD, 12));
		acceptbutton.setBounds(203, 278, 100, 23);
		depositframe.getContentPane().add(acceptbutton);
		
		entamountlabel = new JLabel("Enter Amount");
		entamountlabel.setHorizontalAlignment(SwingConstants.CENTER);
		entamountlabel.setForeground(Color.WHITE);
		entamountlabel.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		entamountlabel.setBounds(132, 151, 220, 20);
		depositframe.getContentPane().add(entamountlabel);
		
		amountfield = new JTextField();
		amountfield.setBounds(120, 185, 242, 30);
		depositframe.getContentPane().add(amountfield);
		amountfield.setColumns(10);
	}

}
